app.controller("homeController", function ($scope, $http, $rootScope, $location, ToastService) {

});
